package com.happy.app.view;
import com.happy.app.model.ModelFoo;

public class ViewBar{
	
	public void showJvmInfo(ModelFoo model){
		System.out.println("This program is running on ..."+model.getJVMInfo());
	}
}