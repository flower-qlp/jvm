package com.happy.app.model;

public class ModelFoo{
	
	public String getJVMInfo(){
		return "JVM version"+System.getProperty("java.version");
	}
	
}