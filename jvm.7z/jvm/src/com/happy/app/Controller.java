package com.happy.app;
import com.happy.app.model.ModelFoo;
import com.happy.app.view.ViewBar;

public class Controller{
	
	public static void main(String[] args){
		ViewBar view=new ViewBar();
		view.showJvmInfo(new ModelFoo());
	}
}